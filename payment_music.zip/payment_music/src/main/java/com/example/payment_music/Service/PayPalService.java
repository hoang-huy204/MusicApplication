package com.example.payment_music.Service;

import com.example.payment_music.Dto.BillDto;
import com.paypal.api.payments.*;
import com.paypal.base.rest.APIContext;
import com.paypal.base.rest.PayPalRESTException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

@Service
public class PayPalService {

    @Value("${paypal.client_Id}")
    private String client_Id;

    @Value("${paypal.secret_Key}")
    private String secret_Key;

    @Value("${paypal.model}")
    private String model;

    public String create_Payment(BillDto billDto) throws PayPalRESTException {
        Payer payer = get_PayerInformation(billDto.getUser_Name(), billDto.getEmail());
        RedirectUrls redirectUrls = getRedirectUrls();
        List<Transaction> list_Transaction = getTransaction(billDto);

        Payment payment_Detail = new Payment();
        payment_Detail.setTransactions(list_Transaction);
        payment_Detail.setRedirectUrls(redirectUrls);
        payment_Detail.setPayer(payer);
        payment_Detail.setIntent("sale");

        APIContext apiContext = new APIContext(client_Id, secret_Key, model);
        Payment approved_Payment = payment_Detail.create(apiContext);
        return get_ApprovalLink(approved_Payment);
    }

    private String get_ApprovalLink(Payment approved_Payment) {
        List<Links> links = approved_Payment.getLinks();
        String approval_Link = null;
        for (Links link : links) {
            if (link.getRel().equalsIgnoreCase("approval_url")) {
                approval_Link = link.getHref();
                break;
            }
        }
        return approval_Link;
    }

    private RedirectUrls getRedirectUrls() {
        RedirectUrls redirectUrls = new RedirectUrls();
        redirectUrls.setReturnUrl("http://localhost:8080/Payment/getPaymentValue");
        redirectUrls.setCancelUrl("http://localhost:8080/Payment/cancel");
        return redirectUrls;
    }

    private Payer get_PayerInformation(String name, String email) {
        Payer payer = new Payer();
        payer.setPaymentMethod("paypal");
        PayerInfo payerInfo = new PayerInfo();
        payerInfo.setFirstName(name)
                .setEmail(email);
        payer.setPayerInfo(payerInfo);
        return payer;
    }

    private List<Transaction> getTransaction(BillDto billDto) {
        Details details = new Details();
        details.setSubtotal(billDto.getAmount());

        Amount amount = new Amount();
        amount.setCurrency("USD");
        amount.setTotal(billDto.getAmount());
        amount.setDetails(details);

        Transaction transaction = new Transaction();
        transaction.setAmount(amount);
        transaction.setDescription(billDto.getPackage_music());

        ItemList itemList = new ItemList();
        List<Item> items = new ArrayList<>();

        Item item = new Item();
        item.setCurrency("USD");
        item.setName(billDto.getPackage_music());
        item.setDescription(billDto.getPackage_validity() + "|" + billDto.getPackage_id());

        item.setPrice(billDto.getAmount());
        item.setQuantity("1");

        items.add(item);
        itemList.setItems(items);
        transaction.setItemList(itemList);


        List<Transaction> list_Transaction = new ArrayList<>();
        list_Transaction.add(transaction);

        return list_Transaction;
    }

    public Payment get_PaymentDetails(String paymentId) throws PayPalRESTException {
        APIContext apiContext = new APIContext(client_Id, secret_Key, model);
        return Payment.get(apiContext, paymentId);
    }

    public Payment executePayment(String paymentId, String payerId)
            throws PayPalRESTException {
        PaymentExecution paymentExecution = new PaymentExecution();
        paymentExecution.setPayerId(payerId);
        Payment payment = new Payment().setId(paymentId);
        APIContext apiContext = new APIContext(client_Id, secret_Key, model);
        return payment.execute(apiContext, paymentExecution);
    }

}
