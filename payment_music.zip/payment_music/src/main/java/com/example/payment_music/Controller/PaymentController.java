package com.example.payment_music.Controller;

import com.example.payment_music.Dto.BillDto;
import com.example.payment_music.Dto.PaymentDetailDto;
import com.example.payment_music.Service.PayPalService;
import com.paypal.api.payments.PayerInfo;
import com.paypal.api.payments.Payment;
import com.paypal.api.payments.Transaction;
import com.paypal.base.rest.PayPalRESTException;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import lombok.Setter;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/Payment")
@RequiredArgsConstructor
@Setter
@Getter
public class PaymentController {

    private final PayPalService payPalService;

    private String _paymentId;

    private String _payerId;

    @PostMapping("/createPayment")
    @ResponseBody
    public ResponseEntity<String> getValue(@RequestBody BillDto billDto) {
        try {
            String approval_Link = payPalService.create_Payment(billDto);
            return ResponseEntity.ok(approval_Link);
        } catch (PayPalRESTException e) {
            if (e.getResponsecode() == 401) {
                return ResponseEntity.badRequest().build();
            }
        }
        return ResponseEntity.badRequest().build();
    }

    @GetMapping("/error")
    public String errorPage() {
        return "error";
    }

    @GetMapping("/getPaymentValue")
    @ResponseBody
    public String confirm(@RequestParam String paymentId, @RequestParam String PayerID) {
        set_paymentId(paymentId);
        set_payerId(PayerID);
        return "";
    }

    @PostMapping("/checkPayment")
    @ResponseBody
    public ResponseEntity<BillDto> checkPayment(@RequestBody PaymentDetailDto paymentDetailDto) {
        if (paymentDetailDto != null) {
            if (_paymentId.equals(paymentDetailDto.getPayment_Id()) && _payerId.equals(paymentDetailDto.getPayer_Id())) {
                try {
                    Payment payment = payPalService.get_PaymentDetails(paymentDetailDto.getPayment_Id());
                    PayerInfo payerInfo = payment.getPayer().getPayerInfo();
                    Transaction transaction = payment.getTransactions().getFirst();
                    String value_package = transaction.getItemList().getItems().getFirst().getDescription();
                    String[] values = value_package.split("\\|");
                    String email = payerInfo.getEmail();
                    String name = payerInfo.getFirstName();
                    String package_music = transaction.getItemList().getItems().getFirst().getName();
                    String package_price = transaction.getItemList().getItems().getFirst().getPrice();
                    return ResponseEntity.ok(new BillDto(name, email, package_price, values[1], values[0], package_music));
                } catch (PayPalRESTException e) {
                    e.printStackTrace();
                }
            } else {
                return ResponseEntity.badRequest().build();
            }
        } else {
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }


    @PostMapping("/execute")
    public ResponseEntity<String> execute(@RequestBody PaymentDetailDto paymentDetailDto) {
        if (_paymentId.equals(paymentDetailDto.getPayment_Id()) && _payerId.equals(paymentDetailDto.getPayer_Id())) {
            try {
                if (paymentDetailDto != null) {
                    Payment payment = payPalService.executePayment(paymentDetailDto.getPayment_Id(), paymentDetailDto.getPayer_Id());
                    if (payment.getState().equals("approved")) {
                        return ResponseEntity.ok("finish");
                    }
                }
            } catch (PayPalRESTException e) {
                e.printStackTrace();
            }
        } else {
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    @GetMapping("/cancel")
    public String cancel() {
        return "cancel";
    }
}
