package com.example.payment_music.Dto;

import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BillDto {
    private String user_Name;
    private String email;
    private String amount;
    private String package_id;
    private String package_validity;
    private String package_music;
}
