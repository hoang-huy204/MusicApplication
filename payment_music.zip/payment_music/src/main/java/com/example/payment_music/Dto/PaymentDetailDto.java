package com.example.payment_music.Dto;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PaymentDetailDto {
    private String payment_Id;
    private String payer_Id;
}
