package com.example.payment_music.Dto;

import lombok.*;

import java.math.BigDecimal;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PackageDto {
    private Integer id;
    private String packageName;
    private BigDecimal packagePrice;
    private Integer validity;

}
