package com.example.payment_music;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentMusicApplicationTests {

	@Test
	void contextLoads() {
	}

}
